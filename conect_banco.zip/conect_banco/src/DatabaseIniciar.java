import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseIniciar {

    // Dados de conexão com o servidor MySQL
    private static final String DB_URL = "jdbc:mysql://localhost:3306/";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "28082004@Luga"; // Substitua pelo seu password

    /**
     * Método para verificar se o banco de dados existe e criá-lo se necessário.
     */
    public static void iniciarDatabase() {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement()) {

            // Verifica se o banco de dados 'ecogastos' já existe
            ResultSet resultSet = statement.executeQuery("SHOW DATABASES LIKE 'ecogastos'");
            if (!resultSet.next()) {
                System.out.println("Banco de dados 'ecogastos' não encontrado. Criando banco e tabelas...");
                
                // Executa o comando para criar o banco e as tabelas
                statement.execute("CREATE DATABASE ecogastos");
                statement.execute("USE ecogastos");

                // Comando SQL para criar a tabela 'usuario'
                String createUsuarioTable = """
                        CREATE TABLE usuario (
                            idusuario INT AUTO_INCREMENT PRIMARY KEY,
                            nome_usuario VARCHAR(100) NOT NULL,
                            email VARCHAR(255) UNIQUE NOT NULL,
                            senha VARCHAR(255) NOT NULL
                        )
                        """;
                statement.execute(createUsuarioTable);

                // Comando SQL para criar a tabela 'historico'
                String createHistoricoTable = """
                        CREATE TABLE historico (
                            idhistorico INT AUTO_INCREMENT PRIMARY KEY,
                            idusuario INT NOT NULL,
                            resultado VARCHAR(255),
                            descricao TEXT,
                            FOREIGN KEY (idusuario) REFERENCES usuario(idusuario)
                        )
                        """;
                statement.execute(createHistoricoTable);

                System.out.println("Banco de dados e tabelas criados com sucesso.");
            } else {
                System.out.println("Banco de dados 'ecogastos' já existe. Nenhuma ação necessária.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Chamando o método para verificar e inicializar o banco de dados
        iniciarDatabase();
    }
}
