import calculo.calculoAgua;

import java.util.Scanner;

import InsertDAO.UsuarioDAO;
import SelectDAO.selectHistoricoDAO;
import SelectDAO.selectLoginDAO;

public class main {
            public static void main(String[] args) throws Exception {

               Scanner scanner = new Scanner(System.in);
               int LerNum;


               System.out.println("olá bem vindo ao projeto ecogasto");
               int PararCodigo = 0;

               while (PararCodigo == 0) {
                
                System.out.println("para iniciar aperte:  ");
                System.out.println(" 1 caso já tenha seu login");
                System.out.println(" 2 caso não tenha login e queira fazer o cadastro");
                System.out.println(" 3 caso deseje encerrar o codigo");
                    LerNum = scanner.nextInt();
                System.out.println(LerNum);
                    if(LerNum == 1 ){
                                              
                        if (new selectLoginDAO().login()) {
                            
                            while (PararCodigo == 0) {


                                System.out.println("\nbem vindo ao projeto ecogastos");
                                System.out.println("para acessar a nossa calculadora aperte 1 ");
                                System.out.println("para acessar seu hístoico e ver seus calculos anteriores aperte 2");
                                System.out.println("para encerrar o código aperte 3");
                                LerNum = scanner.nextInt();
                              
                                if (LerNum == 1) {
                                    System.out.println("bem vindo a calculadora ecogastos, iremos fazer um calculo para saber sobre o seu consumo de água em sua residencia");
                                    System.out.println("basta responder as perguntas abaixo para ver o resultado:");
                                    System.out.println(new calculoAgua().CalcularAgua());
                                
                                }else if(LerNum == 2){
                                    new selectHistoricoDAO().exibirHistorico();

                                }else if(LerNum == 3){
                                    PararCodigo = 1;
                                }else{
                                    System.out.println("coloque um numero valido");
                                }

                                
                            }

                        }
                        

                    }else if(LerNum == 2){
                        
                        if(new UsuarioDAO().cadastrarUsuario()){
                            System.out.println("volte e faça o login");
                        }
                            
                    }else if (LerNum == 3) {
                        PararCodigo = 1;

                    }else{
                    System.out.println("favor colocar um numero valido ");
                    }
               }

        }
}
