package SelectDAO;
import conexao.conexao;
import usuario.Usuario;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class selectLoginDAO {
    Scanner scanner = new Scanner(System.in);
       
    private static int IdUsuariologado;
        
        public static int getIdUsuariologado() {
            return IdUsuariologado;
        }

        public static void setIdUsuariologado(int IdUsuariologado) {
            selectLoginDAO.IdUsuariologado = IdUsuariologado;
        }

        public static boolean vereficaLogin(Usuario usuario ){

            String sql = "SELECT * FROM usuario WHERE email = ?";

            try (PreparedStatement pstmt = conexao.getConexao().prepareStatement(sql)) {
                pstmt.setString(1, usuario.getEmail());
                
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    //System.out.println("\nLogin bem-sucedido! Bem-vindo, "  + "!");
                    return false;
                } else {
                   // System.out.println("\n Nome de usuário ou senha incorretos.");
                    return true;
    
                }
            } catch (SQLException e) {
                System.out.println("\n Erro: " + e.getMessage());
                return false;
    
            }

        }

        public static boolean login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite seu Email de usuário: ");
        String email = scanner.nextLine();
        System.out.print("Digite sua senha: ");
        String senha = scanner.nextLine();
        
        String sql = "SELECT * FROM usuario WHERE email = ? AND senha = ?";

        try (PreparedStatement pstmt = conexao.getConexao().prepareStatement(sql)) {
            pstmt.setString(1, email);
            pstmt.setString(2, senha);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("\nLogin bem-sucedido! Bem-vindo, " + email + "!");
                setIdUsuariologado(rs.getInt("idusuario"));
                return true;
            } else {
                System.out.println("\n Nome de usuário ou senha incorretos.");
                return false;

            }
        } catch (SQLException e) {
            System.out.println("\n Erro ao realizar login: " + e.getMessage());
            return false;

        }
    }
}

