package InsertDAO;
import conexao.conexao;
import java.sql.PreparedStatement;
import usuario.historico;

public class HistoricoDAO {
    
    public void cadastrarHistorico(historico historico){

        String sql = "INSERT INTO historico (idusuario, resultado, descricao) VALUES (?, ?, ?)";

        PreparedStatement ps = null;
        try {
            ps = conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, historico.getIdusuario());
            ps.setDouble(2, historico.getResultado());
            ps.setString(3, historico.getDiscricao());
            
            ps.execute();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("historico não registrado");
        }
    }
}
