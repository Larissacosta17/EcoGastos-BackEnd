package InsertDAO;

import java.sql.PreparedStatement;
import java.util.Scanner;

import SelectDAO.selectLoginDAO;
import conexao.conexao;
import usuario.Usuario;

public class UsuarioDAO {
    
 
    
    public boolean cadastrarUsuario(){

            Scanner scanner = new Scanner(System.in);
              
            System.out.println("favor coloque seu nome: ");
            String nome_usuario = scanner.nextLine();

            System.out.println("favor coloque seu Email");
            String email = scanner.nextLine();

            System.out.println("favor defina sua senha");
            String senha = scanner.nextLine();
            
            Usuario usuario = new Usuario();
            usuario.setNome_usuario(nome_usuario);
            usuario.setEmail(email);
            usuario.setSenha(senha);

            if(selectLoginDAO.vereficaLogin(usuario)){

                String sql = "INSERT INTO usuario (nome_usuario, email, senha) VALUES (?, ?, ?)";

                PreparedStatement ps = null;
                try {
                    ps = conexao.getConexao().prepareStatement(sql);
                    ps.setString(1, usuario.getNome_usuario());
                    ps.setString(2, usuario.getEmail());
                    ps.setString(3, usuario.getSenha());
                
                    ps.execute();
                    System.out.println("Usuário cadastrado");
                    return true;
                    
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;

                }
            } else{
                System.out.println("Email já cadastrado coloque outro");
                return false;
            }

    }
}
