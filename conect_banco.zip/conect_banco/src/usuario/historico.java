package usuario;

public class historico {
 
    private int idhistorico;
    private int idusuario;
    private double resultado;
    private String discricao;
    
    public int getIdhistorico() {
        return idhistorico;
    }
    public void setIdhistorico(int idhistorico) {
        this.idhistorico = idhistorico;
    }
    
    
    public int getIdusuario() {
        return idusuario;
    }
    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }
    
    
    public double getResultado() {
        return resultado;
    }
    public void setResultado(double resultado) {
        this.resultado = resultado;
    }
    
    
    public String getDiscricao() {
        return discricao;
    }
    public void setDiscricao(String discricao) {
        this.discricao = discricao;
    }


    
}
